#include <hFramework.h>

namespace hFramework {
namespace OTA {

bool run(uint32_t crc32, int length, hStreamDev& dev);
}
}
